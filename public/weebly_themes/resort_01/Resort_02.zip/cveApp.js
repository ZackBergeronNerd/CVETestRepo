var app = angular.module("cveApp", ['angulartics', 'angulartics.cve'], function($interpolateProvider) {
	$interpolateProvider.startSymbol('<%');
	$interpolateProvider.endSymbol('%>');
});

app.controller("cveCtrl", function($scope, $http, $analytics, $location) {
	$analytics.pageTrack($location.path());
	$analytics.eventTrack('packageOpen', { c: '19xs9d8a', u: 'dksowl' });
});